﻿// using System.Collections;
// using System.Collections.Generic;
// using UnityEngine;

// namespace Collision
// {
//     public class Wall2D : MonoBehaviour
//     {
//         /*Your code*/
//     }
// }
